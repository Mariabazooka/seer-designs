SEER SIX-INTERFACE CONCEPT PROTOTYPE — ORGANIZED FOR BOUNTY REVIEW

Pages:
- index.html — Seer Homepage
- app.html — Seer App / Market Explorer
- deep.html — Deep
- futarchy.html — Futarchy
- opportunity.html — Opportunity Markets
- risk.html — Risk Pricing

All six pages are independently addressable and share a consistent responsive visual system and navigation. Upload all six HTML files to the same public static-hosting folder (for example, the root of a GitHub Pages repository) to get six distinct URLs.

Important before submitting:
- This is a concept prototype using illustrative data, not live Seer market data.
- Review the official Electric Foundation Figma brand kit and refine the exact colors, type, logo, and components to match it.
- Test all links and controls on desktop and mobile.
- Replace placeholder identity details and include your X handle in the Poidh claim.
- Attach a preview image and list all six public URLs in the claim description.
- Explain any deliberate departures from the Electric Foundation kit.
